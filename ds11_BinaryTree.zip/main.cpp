#include <stdio.h>

class CBTree
{
public:
	CBTree* L;
	CBTree* R;
	int		N;
	
public:
	CBTree();
	CBTree(int _N);
	~CBTree();
	void AddTree(CBTree* p);
	void preorder();
	void preorder(CBTree* p);
	void inorder();
	void inorder(CBTree* p);
	void postorder();
	void postorder(CBTree* p);
};


int main()
{
	CBTree* p= new CBTree(6);
	p->AddTree(new CBTree(4));
	p->AddTree(new CBTree(2));
	p->AddTree(new CBTree(1));
	p->AddTree(new CBTree(3));
	p->AddTree(new CBTree(5));
	p->AddTree(new CBTree(7));
	
	printf("Preorder...\n");
	p->preorder();
	printf("\n\n");
	printf("Inorder...\n");
	p->inorder();
	printf("\n\n");
	printf("Postorder...\n");
	p->postorder();
	printf("\n\n");
	
	delete p;
	
	p= NULL;
	
	return 0;
}



CBTree::CBTree()
{
	L = NULL;
	R = NULL;
	N = 0;
}

CBTree::CBTree(int _N)
{
	L = NULL;
	R = NULL;
	N = _N;
}


CBTree::~CBTree()
{
	if(L)	{	delete L;	L = NULL;	}
	if(R)	{	delete R;	R = NULL;	}
}

void CBTree::AddTree(CBTree* p)
{
	if(p->N < N) 
		if(L)
			L->AddTree(p);
		else
			L=p;
	
	else
		if(R)
			R->AddTree(p);
		
		else
			R=p;
}

void CBTree::preorder()
{
	printf("(%3d)", N);
	preorder(L);
	preorder(R);		
}

void CBTree::preorder(CBTree* p)
{
	if(p)
	{
		printf("(%3d)",p->N);
		preorder(p->L);
		preorder(p->R);			
	}
}


void CBTree::inorder()
{
	inorder(L);
	printf("(%3d)", N);
	inorder(R);		
}

void CBTree::inorder(CBTree* p)
{
	if(p)
	{
		inorder(p->L);
		printf("(%3d)",p->N);
		inorder(p->R);			
	}
}

void CBTree::postorder()
{
	postorder(L);
	postorder(R);
	printf("(%3d)", N);
}

void CBTree::postorder(CBTree* p)
{
	if(p)
	{
		postorder(p->L);
		postorder(p->R);
		printf("(%3d)",p->N);
	}
}
