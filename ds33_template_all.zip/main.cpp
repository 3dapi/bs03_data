
// Basic Bubble, Insertion, Shell, Quick Sorting Test
// Date: 03/19/2007 edited by Bread Mackerel
// Copyleft: All rights not reserved.
//
// I want no any other questions, answers..

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include <math.h>


const int FALSE= 0;
const int TRUE = 1;
//const int INT_MIN = 0x80000000;		// -2147483648
//const int INT_MAX = 0x7FFFFFFF;

////////////////////////////////////////////////////////////////////////////////
// for Data Swap
template<class T>
void Tswap(T* t1, T* t2)
{
	T t3;
	memcpy(&t3, t1, sizeof(T));
	memcpy(t1, t2, sizeof(T));
	memcpy(t2, &t3, sizeof(T));
}



////////////////////////////////////////////////////////////////////////////////
// Bubble Sort
template<class T1, class T2>
void BubbleSort(T1* _F, T1* _L, T2 _P)
{
	int Sorted=FALSE;

	T1*	M	= _F;
	T1*	E	= _L-1;

	while(!Sorted)
	{
		Sorted = TRUE;

		M = _F;

		for( ; M != E; ++M)
		{
			if( !_P( *M, *(M+1)  ))
			{
				::Tswap( M, M+1);
				Sorted = FALSE;
			}
		}

		--E;
	}
}


////////////////////////////////////////////////////////////////////////////////
// Insert Sort
template<class T1, class T2>
void InsertionSort(T1* _F, T1* _L, T2 _P)
{
	T1	V;
	T1*	M;
	T1*	B	= _F+1;

	int	bSwap = 0;

	for( ; B != _L; ++B)
	{
		memcpy(&V, B, sizeof(T1));

		M = B;

		while(  !_P( *(M-1),V) )
		{
			bSwap = 1;

			memcpy(M, M-1, sizeof(T1));

			--M;

			if( M == _F)
				break;
		}

		if(bSwap)
			memcpy(M, &V, sizeof(T1));
	}
}




////////////////////////////////////////////////////////////////////////////////
// Shell Sort
template<class T1, class T2>
void ShellSort(T1* Lst, int n, T2 _P)
{
	int h=1, i, j;
	T1	V;

	do
	{
		h= 3*h + 1;
	}while (h<n);


	do
	{
		h = h/3;

		for(i=h; i<n; ++i)
		{
			memcpy(&V, &Lst[i], sizeof(T1));
			j = i;

			while( !_P(Lst[j-h], V) )
			{
				memcpy(&Lst[j], &Lst[j-h], sizeof(T1));

				j -=h;

				if(j<h)
					break;
			}

			memcpy(&Lst[j], &V, sizeof(T1));
		}


	} while(h>1);
}



// Quick Sort: where it has bugs
//template<class T1, class T2>
//void QuickSort(T1* _F, T1* _L, T2 _P)
//{
//	T1 *B, *E, V;
//	
//	if(_F<_L)
//	{
//		B = _F;
//		E = _L+1;
//		memcpy(&V, _F, sizeof(T1));
//
//		while(1)
//		{
//			do{} while( _P(*++B, V) );
//			do{} while( _P(V, *--E) );
//
//			if(B<E)
//				Tswap(B, E);
//			else
//				break;
//		}
//
//		Tswap(_F, E);
//		QuickSort(_F, E-1, _P);
//		QuickSort(E+1, _L, _P);
//	}
//}


// Quick sort1
//template<class T1, class T2>
//void QuickSort0(T1* _F, T1* _L, T2 _P)
//{
//	T1 *B, *E, V;
//	
//	if(_F<_L)
//	{
//		B = _F;
//		E = _L;
//		memcpy(&V, _F, sizeof(T1));
//
//		while(1)
//		{
//			while(1)
//			{
//				++B;
//
//				if( B>_L)
//					break;
//				
//				if( _P(V, *B))
//					break;
//			}
//
//			while(1)
//			{
//				if( E<=_F)
//					break;
//
//				if( _P(*E, V))
//					break;
//
//				--E;
//			}
//
//			if(B<E)
//				Tswap(B, E);
//			else
//				break;
//		}
//
//		Tswap(_F, E);
//		QuickSort0(_F, E-1, _P);
//		QuickSort0(E+1, _L, _P);
//	}
//}
//
//
//template<class T1, class T2>
//void QuickSort(T1* _F, T1* _L, T2 _P)
//{
//	QuickSort0(_F, _L-1, _P);
//}


// Quick Sort2
template<class T1, class T2>
void QuickSort(T1* _F, T1* _L, T2 _P)
{
	T1 *B, *E, V;

	--_L;
	
	if(_F<_L)
	{
		B = _F;
		E = _L;
		memcpy(&V, _F, sizeof(T1));

		while(1)
		{
			while(1)
			{
				++B;

				if( B>_L)
					break;
				
				if( _P(V, *B))
					break;
			}

			while(1)
			{
				if( E<=_F)
					break;

				if( _P(*E, V))
					break;

				--E;
			}

			if(B<E)
				Tswap(B, E);
			else
				break;
		}

		Tswap(_F, E);
		QuickSort(_F, E, _P);
		QuickSort(E+1, _L+1, _P);
	}
}




struct MySt
{
	int a;
	double c;
};


template<class T>
struct Greater
{
	bool operator()(const T& v1, const T& v2)
	{
		return v1.c < v2.c;
	}
};




void BubbleSortTest(int n);
void InsertSortTest(int n);
void ShellSortTest(int n);
void QuickSortTest(int n);


void main()
{
	BubbleSortTest(50);
	InsertSortTest(50);
	ShellSortTest(50);
	QuickSortTest(50);
}






void BubbleSortTest(int n)
{
	printf("Bubble Sort ----------\n");

	int	i = 0;
	MySt* p= new MySt[n];

	for(i=0; i<n; ++i)
	{
		p[i].a = (i+1)*n;
		p[i].c = rand()%n;
		p[i].c = expl(p[i].c);
	}

	BubbleSort(p, p+n, Greater<MySt>());
	
	for(i=0; i<n; ++i)
		printf("%5d  %45.lf\n", p[i].a, p[i].c);

	printf("\n\n");

	delete [] p;
}

void InsertSortTest(int n)
{
	printf("Insert Sort ----------\n");

	int	i = 0;
	MySt* p= new MySt[n];

	for(i=0; i<n; ++i)
	{
		p[i].a = (i+1)*n;
		p[i].c = rand()%n;
		p[i].c = expl(p[i].c);
	}

	InsertionSort(p, p+n, Greater<MySt>());
	
	for(i=0; i<n; ++i)
		printf("%5d  %45.lf\n", p[i].a, p[i].c);

	printf("\n\n");

	delete [] p;
}


void ShellSortTest(int n)
{
	printf("Shell Sort ----------\n");

	int	i = 0;
	MySt* p= new MySt[n];

	for(i=0; i<n; ++i)
	{
		p[i].a = (i+1)*n;
		p[i].c = rand()%n;
		p[i].c = expl(p[i].c);
	}

	ShellSort(p, n, Greater<MySt>());
	
	for(i=0; i<n; ++i)
		printf("%5d  %45.lf\n", p[i].a, p[i].c);

	printf("\n\n");

	delete [] p;
}


void QuickSortTest(int n)
{
	printf("Quick Sort ----------\n");

	int	i = 0;
	MySt* p= new MySt[n];

	for(i=0; i<n; ++i)
	{
		p[i].a = (i+1)*n;
		p[i].c = rand()%n;
		p[i].c = expl(p[i].c);
	}

	QuickSort(p, p + n, Greater<MySt>());

	for(i=0; i<n; ++i)
		printf("%5d %5d  %45.lf\n", i, p[i].a, p[i].c);

	printf("\n\n");

	delete [] p;
}
