#include "_StdAfx.h"


struct SBubble
{
	int	iLvl;

	SBubble()
	{
		iLvl = rand()%65535;
	}
};

void BubbleSort();


int main()
{
//	CCharInf*	pCharInf = NULL;
//
//	pCharInf = new CCharInf;
//	pCharInf->BinLoad();
//	pCharInf->TxtWrite();
//	
//	SAFE_DELETE(	pCharInf	);


	BubbleSort();

	return 1;
}


void BubbleSort()
{
	int			iNum=128;
	SBubble*	pBubble = new SBubble[iNum];

	int			i, j;

	for (i=0 ; i<iNum-1;++i)
	{
		for(j=i; j<iNum; ++j)
		{
			if (pBubble[i].iLvl < pBubble[j].iLvl)
			{
				SBubble temp;
				memcpy (&temp, &pBubble[i], sizeof(SBubble));
				memcpy (&pBubble[i], &pBubble[j], sizeof(SBubble));
				memcpy (&pBubble[j], &temp, sizeof(SBubble));
			}
		}
	}




	for (i=0 ; i<iNum;++i)
	{
		printf("%d	%d\n", i, pBubble[i].iLvl);
	}


	SAFE_DELETE_ARRAY(	pBubble	);
		
}