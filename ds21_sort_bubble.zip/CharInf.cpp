#include "_StdAfx.h"

char*	sLdCmd[] =
{
	"RecNum:",
	"Rec*",
};


CCharInf::CCharInf()
{
	m_iNum	= 0;
	m_pRec	= NULL;

	strcpy(m_sFileBin, "CharInfo.bin");
	strcpy(m_sFileTxt, "CharInfo.txt");

//	m_iNum	= 12;
//	m_pRec = new SCharInf[m_iNum];
//
//	int i, j;
//
//	for(i=0; i<m_iNum; ++i)
//	{
//		char	sUid[32];
//
//		sprintf(sUid, "0000000000000000%d", rand()%65535);
//
//		int iLen = strlen(sUid);
//
//		for(j= iLen-8; j<iLen; ++j)
//		{
//			m_pRec[i].sUID[j-(iLen-8)] = sUid[j];
//		}
//
//		m_pRec[i].iLvl = rand()%52;
//	}
}

CCharInf::~CCharInf()
{
	Destroy();
}



void CCharInf::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pRec	);
}


int	CCharInf::BinLoad()
{
	FILE*	fp;

	fp = fopen(m_sFileBin, "rb");

	if(NULL == fp)
		return -1;

	fread(&m_iNum, sizeof(int), 1, fp);

	printf("%s %2d\n", sLdCmd[0], m_iNum);

	if(m_iNum<=0)
	{
		fclose(fp);
		return -1;
	}

	m_pRec = new SCharInf[m_iNum];

	fread(m_pRec, sizeof(SCharInf), m_iNum, fp);
	
	fclose(fp);


	
	
	for(int i=0; i<m_iNum; ++i)
	{
		printf("%s %4d %10s %4d\n"
			,	sLdCmd[1]
			,	i
			,	m_pRec[i].sUID
			,	m_pRec[i].iLvl
		);
	}

	return 1;
}


int	CCharInf::TxtLoad()
{
	FILE*	fp;
	char sLine[512];

	fp = fopen(m_sFileTxt, "rt");

	if(NULL == fp)
	{
		printf("%s file open failed\n", m_sFileTxt);
		return -1;
	}

	


	while(!feof(fp))
	{
		fgets(sLine, 512, fp);

		if( 0 == strncmp(sLine, sLdCmd[0], strlen(sLdCmd[0]) ) ) 
		{
			sscanf(sLine, "%*s %d", &m_iNum);

			if(m_iNum>0)
				m_pRec = new SCharInf[m_iNum];
		}


		if(0 == strncmp(sLine, sLdCmd[1], strlen(sLdCmd[1]) ) ) 
		{
			int iRec;
			sscanf(sLine, "%*s %d", &iRec);
			sscanf(sLine, "%*s %*s	%s %d", m_pRec[iRec].sUID, &m_pRec[iRec].iLvl);			
		}
	}
	
	fclose(fp);



	printf("%s %2d\n", sLdCmd[0], m_iNum);
	
	for(int i=0; i<m_iNum; ++i)
	{
		printf("%s %4d %10s %4d\n"
			,	sLdCmd[1]
			,	i
			,	m_pRec[i].sUID
			,	m_pRec[i].iLvl
		);
	}

	return 1;
}


int	CCharInf::TxtWrite()
{
	FILE*	fp;

	fp = fopen(m_sFileTxt, "wt");

	fprintf(fp, "%s %2d\n", sLdCmd[0], m_iNum);


	for(int i=0; i<m_iNum; ++i)
	{
		printf("%s %4d %10s %4d\n"
			,	sLdCmd[1]
			,	i
			,	m_pRec[i].sUID
			,	m_pRec[i].iLvl
			);

		fprintf(fp, "%s %4d %10s %4d\n"
			,	sLdCmd[1]
			,	i
			,	m_pRec[i].sUID
			,	m_pRec[i].iLvl
			);
	}

	fclose(fp);

	return 1;
}


int	CCharInf::BinWrite()
{
	FILE*	fp;

	if(m_iNum<=0)
	{
		return -1;
	}

	fp = fopen(m_sFileBin, "wb");

	if(NULL == fp)
		return -1;

	fwrite(&m_iNum, sizeof(int), 1, fp);

	if(m_iNum<=0)
	{
		fclose(fp);
		return -1;
	}

	fwrite(m_pRec, sizeof(SCharInf), m_iNum, fp);
	fclose(fp);

	return 1;
}