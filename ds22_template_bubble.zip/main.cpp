
// Basic Bubble, Insertion, Shell, Quick Sorting Test
// Date: 03/19/2007 edited by Bread Mackerel
// Copyleft: All rights not reserved.
//
// I want no any other questions, answers..

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include <math.h>


const int FALSE= 0;
const int TRUE = 1;
//const int INT_MIN = 0x80000000;		// -2147483648
//const int INT_MAX = 0x7FFFFFFF;

////////////////////////////////////////////////////////////////////////////////
// for Data Swap
template<class T>
void Tswap(T* t1, T* t2)
{
	T t3;
	memcpy(&t3, t1, sizeof(T));
	memcpy(t1, t2, sizeof(T));
	memcpy(t2, &t3, sizeof(T));
}



////////////////////////////////////////////////////////////////////////////////
// Bubble Sort
template<class T1, class T2>
void BubbleSort(T1* _F, T1* _L, T2 _P)
{
	int Sorted=FALSE;

	T1*	M	= _F;
	T1*	E	= _L-1;

	while(!Sorted)
	{
		Sorted = TRUE;

		M = _F;

		for( ; M != E; ++M)
		{
			if( !_P( *M, *(M+1)  ))
			{
				::Tswap( M, M+1);
				Sorted = FALSE;
			}
		}

		--E;
	}
}



struct MySt
{
	int a;
	double c;
};


template<class T>
struct Greater
{
	bool operator()(const T& v1, const T& v2)
	{
		return v1.c < v2.c;
	}
};




void BubbleSortTest(int n);


void main()
{
	BubbleSortTest(50);
}





void BubbleSortTest(int n)
{
	printf("Bubble Sort ----------\n");

	int	i = 0;
	MySt* p= new MySt[n];

	for(i=0; i<n; ++i)
	{
		p[i].a = (i+1)*100;
		p[i].c = rand()%100;
		p[i].c = expl(p[i].c);
	}

	BubbleSort(p, p+n, Greater<MySt>());
	
	for(i=0; i<n; ++i)
		printf("%5d  %45.lf\n", p[i].a, p[i].c);

	printf("\n\n");

	delete [] p;
}

