
// Basic Bubble, Insertion, Shell, Quick Sorting Test
// Date: 03/19/2007 edited by Bread Mackerel
// Copyleft: All rights not reserved.
//
// I want no any other questions, answers..

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>


const int FALSE= 0;
const int TRUE = 1;
const int INT_MIN = 0x80000000;// -2147483648;
const int INT_MAX = 0x7FFFFFFF;

void	SelectionSort(int* &Lst, int n);
void	BubbleSort(int* &Lst, int n);
void	InsertSort(int* &Lst, int n);
void	ShellSort(int* &Lst, int n);

void	QuickSort(int* &Lst, int Left, int Right);

// for Merge Sort
void	MergeSort(int* &Lst, int Left, int Right);
void	Merge(int* &Lst, int Left, int Mid, int Right);


// for Heap Sort
void	HeapSort(int* &Lst, int n);
void	HeapMake(int* &Lst, int Root, int LastNode);


static int compare(const void *v1, const void *v2);

void main()
{
	int TstLst[] ={30, 50, 15, 60, 35, 10, 40, 45, 5, 25, 55, 20};
	int n = sizeof(TstLst)/sizeof(TstLst[0]);

	printf("Selection Sort ----------\n");
	{
		int* p = (int*)alloca(sizeof TstLst);
		memcpy(p, TstLst, sizeof TstLst);

		SelectionSort(p, n);

		for(int i=0; i<n; ++i)
			printf("%2d ", p[i]);
	}

	printf("\n\n");
	printf("Bubble Sort ----------\n");
	{
		int* p = (int*)alloca(sizeof TstLst);
		memcpy(p, TstLst, sizeof TstLst);

		BubbleSort(p, n);

		for(int i=0; i<n; ++i)
			printf("%2d ", p[i]);
	}

	printf("\n\n");
	printf("Insert Sort ----------\n");
	{
		int* p = (int*)alloca(sizeof TstLst);
		memcpy(p, TstLst, sizeof TstLst);

		InsertSort(p, n);

		for(int i=0; i<n; ++i)
			printf("%2d ", p[i]);
	}

	printf("\n\n");
	printf("Quick Sort ----------\n");
	{
		int* p = (int*)alloca(sizeof TstLst);
		memcpy(p, TstLst, sizeof TstLst);

		QuickSort(p, 0, n);

		for(int i=0; i<n; ++i)
			printf("%2d ", p[i]);
	}

	printf("\n\n");
	printf("Merge Sort ----------\n");
	{
		int* p = (int*)alloca(sizeof TstLst);
		::memcpy(p, TstLst, sizeof TstLst);

		int Left =0;
		int Right = n-1;

		MergeSort(p, Left, Right);

		for(int i=0; i<n; ++i)
			printf("%2d ", p[i]);
	}

	printf("\n\n");
	printf("Heap Sort ----------\n");
	{
		int* p = (int*)alloca(sizeof TstLst);
		::memcpy(p, TstLst, sizeof TstLst);

		HeapSort(p, n);

		for(int i=0; i<n; ++i)
			printf("%2d ", p[i]);
	}

	printf("\n\n");
	printf("C ���̺귯���� �� ��Ʈ�� �� ----------\n");
	{
		int* p = (int*)alloca(sizeof TstLst);
		::memcpy(p, TstLst, sizeof TstLst);

		::qsort((void*)p, n, sizeof(int), compare);

		for(int i=0; i<n; ++i)
			printf("%2d ", p[i]);
	}

	printf("\n\n");
}





////////////////////////////////////////////////////////////////////////////////
// for CRT: qsort
static int compare(const void *v1, const void *v2)
{
   if( *((int*)v1) == *((int*)v2))
	   return 0;

   else if( *((int*)v1) < *((int*)v2))
	   return -1;

   return 1;
}



////////////////////////////////////////////////////////////////////////////////
// for Data Swap
template<class T>
void Tswap(T* t1, T* t2)
{
	T t3;
	memcpy(&t3, t1, sizeof(T));
	memcpy(t1, t2, sizeof(T));
	memcpy(t2, &t3, sizeof(T));
}





////////////////////////////////////////////////////////////////////////////////
// Selection Sort
void SelectionSort(int* &Lst, int n)
{
	int i, j, k;

	for(i=0; i<n-1; ++i)
	{
		j=i;

		for(k=i+1; k<n; ++k)
		{
			if(Lst[j] > Lst[k])
				j = k;
		}

		if(j != i)
		{
			::Tswap(&Lst[i], &Lst[j]);
		}
	}
}



////////////////////////////////////////////////////////////////////////////////
// Bubble Sort
void BubbleSort(int* &Lst, int n)
{
	int i,j=n, Sorted = FALSE;

	while(!Sorted)
	{
		Sorted = FALSE;

		for(i=1; i<j; ++i)
		{
			if(Lst[i-1]>Lst[i])
			{
				::Tswap(&Lst[i-1], & Lst[i]);
				Sorted = TRUE;
			}
		}

		--j;
	}
}




////////////////////////////////////////////////////////////////////////////////
// Insert Sort
void InsertSort(int* &Lst, int n)
{
	int i, j, Temp;

	for(i=1; i<n; ++i)
	{
		Temp = Lst[i];
		j = i;

		while(0<j && Temp <Lst[j-1] )
		{
			Lst[j] = Lst[j-1];
			--j;
		}

		if(i != j)
			Lst[j] = Temp;
	}
}



////////////////////////////////////////////////////////////////////////////////
// Shell Sort
void ShellSort(int* &Lst, int n)
{
	int h=1, i, j, Temp;

	do
	{
		h= 3*h + 1;
	}while (h<n);


	do
	{
		h = h/3;

		for(i=h; i<n; ++i)
		{
			Temp = Lst[i];
			j = i;

			while(Lst[j-h]>Temp)
			{
				Lst[j] = Lst[j-h];
				j -=h;

				if(j<h)
					break;
			}

			Lst[j] = Temp;
		}


	} while(h>1);
}


////////////////////////////////////////////////////////////////////////////////
// Quick Sort
//
//template���� �ٲپ��� �� ���� �߻�
//void QuickSort(int* &Lst, int Left, int Right)
//{
//	int i, j, Pivot;
//	
//	if(Left<Right)
//	{
//		i = Left;
//		j = Right+1;
//		Pivot = Lst[Left];
//
//		while(1)
//		{
//			do{} while( Lst[++i] < Pivot );
//			do{} while( Pivot < Lst[--j] );
//
//			if(i<j)
//				Tswap(&Lst[i], &Lst[j]);
//			else
//				break;
//		}
//
//		Tswap(&Lst[Left], &Lst[j]);
//		QuickSort(Lst, Left, j-1);
//		QuickSort(Lst, j+1, Right);
//	}
//}
//
//
// QuickSort() �Լ��� QuickSort0() �Լ��� ȣ���ϴ� ����
// Quick Sort
//void QuickSort0(int* &Lst, int Left, int Right)
//{
//	int i, j, Pivot;
//	
//	if(Left<Right)
//	{
//		i = Left;
//		j = Right;
//		Pivot = Lst[Left];
//
//		while(1)
//		{
//			while(1)
//			{
//				++i;
//
//				if( i>Right || Lst[i] > Pivot)
//					break;
//			}
//
//
//			while(1)
//			{
//				if( j<=Left || Lst[j] < Pivot)
//					break;
//
//				--j;
//			}
//
//			if(i<j)
//				Tswap(&Lst[i], &Lst[j]);
//			else
//				break;
//		}
//
//		Tswap(&Lst[Left], &Lst[j]);
//		QuickSort0(Lst, Left, j-1);
//		QuickSort0(Lst, j+1, Right);
//	}
//}
//
//
//void	QuickSort(int* &Lst, int Left, int Right)
//{
//	QuickSort0(Lst, Left, Right-1);
//}
//
//
// ���� ������ ������ ����
void QuickSort(int* &Lst, int Left, int Right)
{
	int i, j, Pivot;

	--Right;
	
	if(Left<Right)
	{
		i = Left;
		j = Right;
		Pivot = Lst[Left];

		while(1)
		{
			while(1)
			{
				++i;

				if( i>Right)
					break;
				
				if(Lst[i] >Pivot)
					break;
			}


			while(1)
			{
				if(j<=Left)
					break;

				if(Lst[j] < Pivot)
					break;

				--j;
			}

			if(i<j)
				Tswap(&Lst[i], &Lst[j]);
			else
				break;
		}

		Tswap(&Lst[Left], &Lst[j]);
		QuickSort(Lst, Left, j);
		QuickSort(Lst, j+1, Right+1);
	}
}



////////////////////////////////////////////////////////////////////////////////
// fort Merge Sort
void MergeSort(int* &Lst, int Left, int Right)
{
	int Mid;

	if(Left<Right)
	{
		Mid = (Left + Right)/2;
		MergeSort(Lst, Left, Mid);
		MergeSort(Lst, Mid+1, Right);
		Merge(Lst, Left, Mid, Right);
	}
}

////////////////////////////////////////////////////////////////////////////////
// Merge Sort
void Merge(int* &Lst, int Left, int Mid, int Right)
{
	// Allocates Memory on the Stack
	int* Tbuff = (int*)alloca(sizeof(int) * (Right - Left +4));

	int i;
	int nL=Left;
	int nR=Mid+1;
	int nT=0;

	while(nL<=Mid && nR <=Right)
	{
		// �ӽ� ���ۿ� ���� ä���.

		if( Lst[nL] < Lst[nR])
		{
			Tbuff[nT] = Lst[nL];
			++nT;
			++nL;
		}
		else
		{
			Tbuff[nT] = Lst[nR];
			++nT;
			++nR;
		}
	}

	// ���� While���� ���� �κ��� ä�� �ִ´�.

	if(nL>Mid)
	{
		for(i=nR; i<=Right; ++i)
		{
			Tbuff[nT]=Lst[i];
			++nT;
		}
	}

	else
	{
		for(i=nL;i<=Mid; ++i)
		{
			Tbuff[nT]=Lst[i];
			++nT;
		}
	}

	nT = 0;		// �������� ���� �κ�

	for(i=Left; i<=Right; ++i)
	{
		Lst[i] = Tbuff[nT];
		++nT;
	}

}



////////////////////////////////////////////////////////////////////////////////
// Heap Sort
void HeapSort(int* &Lst, int n)
{
	int i;

	for(i=n/2; i>0; --i)
		HeapMake(Lst, i-1, n-1);

	for(i=n-1; i>0; --i)
	{
		Tswap(&Lst[0], &Lst[i]);
		HeapMake(Lst, 0, i-1);
	}
}


////////////////////////////////////////////////////////////////////////////////
// For Heap Sort
void HeapMake(int* &Lst, int Root, int LastNode)
{
	int nParent, nSonLeft, nSonRight, nSon, iRootValue;

	nParent		= Root;
	iRootValue	= Lst[Root];
	nSonLeft	= 2 * nParent + 1;
	nSonRight	= nSonLeft + 1;

	while(nSonLeft <= LastNode)
	{
		if(nSonRight <= LastNode && Lst[nSonLeft] <Lst[nSonRight])
			nSon = nSonRight;

		else
			nSon = nSonLeft;

		if(iRootValue < Lst[nSon])
		{
			Lst[nParent] = Lst[nSon];
			nParent = nSon;
			nSonLeft = nParent * 2 + 1;
			nSonRight= nSonLeft + 1;
		}
		else
			break;

	}// End While


	Lst[nParent] = iRootValue;
}



