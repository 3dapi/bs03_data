
// Basic Bubble, Insertion, Shell, Quick Sorting Test
// Date: 03/19/2007 edited by Bread Mackerel
// Copyleft: All rights not reserved.
//
// I want no any other questions, answers..

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include <math.h>



template<class T>
void CallFunctor1(T _P)
{
	_P();
}


struct Functor1
{
	void operator()()
	{
		printf("Basic Functor with \"operator()()\"\n");
	}
};



template<class T1, class T2>
void CallFunctor2(T1 t, T2 _P)
{
	_P(t);
}

template<class T>
struct Functor2
{
	void operator()(T& t)
	{
		printf("Call Functor with one argument: %d\n", t);
	}
};




template<class T1, class T2>
void CallFunctor3(T1& t1, T1& t2, T1& t3, T2 _P)
{
	int k = _P(t1, t2, t3);

	
}

template<class T>
struct Functor3
{
	int operator()(T& t1, T& t2, T& t3)
	{
		printf("Call Functor with user defined argument list and return: %d %d %d\n"
				, t1.c, t2.c, t3.c);
		return t3.c;
	}
};



struct MySt
{
	int a;
	int b;
	int c;
};

void main()
{
	CallFunctor1(Functor1());

	int i = 10;

	CallFunctor2(i, Functor2<int>() );

	MySt s1;	s1.c = 100;
	MySt s2;	s2.c = 200;
	MySt s3;	s3.c = 300;

	CallFunctor3(s1, s2, s3, Functor3<MySt>()  );
}



